println """
*******************************************************
* You've installed the Spring Security Cas Attribs plugin.
*
*******************************************************
"""
